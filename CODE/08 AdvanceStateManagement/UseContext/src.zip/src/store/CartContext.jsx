import { createContext,useState } from "react";
import { DUMMY_PRODUCTS } from "../dummy-products";

export const CartContext = createContext({
    items: [],
    addUpdateCartItem: () => {}
  });

const CartContextProvider = ({children}) => {
  const [shoppingCart,setShoppingCart]=useState({items:[]});

  function handleCartItem(id, qty=1) {
    setShoppingCart((prev) => {
      const updatedItems = [...prev.items];
      const itemId = updatedItems.findIndex((item) => item.id === id);
      if (itemId === -1) {
        const product = DUMMY_PRODUCTS.find((product) => product.id === id);
        if (product) {
          updatedItems.push({
            id: id,
            img:product.image,
            name: product.title,
            price: product.price,
            quantity: qty,
          });
        }
      } 
      else {
        updatedItems[itemId].quantity+=qty;
        if (updatedItems[itemId].quantity <= 0 || qty==0) {
          updatedItems.splice(itemId, 1); //remove item from list if qty is 0
        }
      }
      return {
        items: updatedItems,
      };
    });
 }
 const ctxValue={
  items:shoppingCart.items,
  addUpdateCartItem:handleCartItem,
 };
 return (
  <CartContext.Provider value={ctxValue} >
    {children}
  </CartContext.Provider>
 )
}

export default CartContextProvider 